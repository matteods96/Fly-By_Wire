#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <signal.h>
#include "GeneratoreFallimenti.h"

void assignChosenPFC(){
	if(process == 1){
		pid = pfc1;
	}
	if(process == 2){
		pid = pfc2;
	}
	if(process == 3){
		pid = pfc3;
	}
}
int randomInteger(int min, int max){
	
	return rand()%(max-min+1)+min;
}
/*se il numero casuale è uguale a 1, la condizione è verificata*/
int calculateProbability(int randomNumber){
	return (randomNumber == 1);
}
int chooseProcess(){
	srand(time(NULL));   //viene reimpostato il seed dei numeri random
	srand(time(NULL));
	srand(time(NULL));
	int process=randomInteger(1,3);
	return process;
}

void displaySignal(char * signal){
		fprintf(fd,"%s",signal);
		fflush(fd);
}

int main(int argc, char * argv[]){
	sleep(1);
	/*apertura file dei pid dei PFC*/
	fd1 = fopen("pid_pfc.txt","r");
	if( fd1 == NULL ) {
		printf("Errore in apertura del file pid_pfc.txt\n");
		exit(1);
	}
	/*lettura dei pid dei PFC dal file condiviso pid_pfc.txt */
	pfc1 = atoi(fgets(buffer,capacity_buffer,fd1));
	pfc2 = atoi(fgets(buffer,capacity_buffer,fd1));
	pfc3 = atoi(fgets(buffer,capacity_buffer,fd1));
	
	remove("failures.log");
	fd=fopen("failures.log", "w");	
	if( fd == NULL ) {
		printf("Errore in apertura del file failures.log\n");
		exit(1);
	}
   /*ciclo che estrae un processo, e invia i segnali con successo ai PFC corrispondenti*/
	while(1){	 
		fprintf(fd,"----------\n");  
		fflush(fd);
		process= chooseProcess();
		assignChosenPFC();

		fprintf(fd,"PFC%d\n",process); 
		fflush(fd);    

		randomNumber=randomInteger(0,SIGSTOP_RANGE);  
		s1 = calculateProbability(randomNumber);
		if(s1 == 1){
			displaySignal("SIGSTOP\n");
			kill(pid,SIGSTOP);
		}
		randomNumber=randomInteger(0,SIGINT_RANGE);
		s2 = calculateProbability(randomNumber);
		if(s2 == 1){
			displaySignal("SIGINT\n");
			kill(pid,SIGINT);
		}
		randomNumber=randomInteger(0,SIGCONT_RANGE);
		s3 = calculateProbability(randomNumber);
		if(s3 == 1){
			displaySignal("SIGCONT\n");
			kill(pid,SIGCONT);
		}
		randomNumber=randomInteger(0,SIGUSR1_RANGE);
		s4 = calculateProbability(randomNumber);
		if(s4 == 1){
			displaySignal("SIGUSR1\n");
			kill(pid,SIGUSR1);
		}
		fprintf(fd,"----------\n");
		fflush(fd);
		pid = 0;
		sleep(1);
	}
	fclose(fd);
	return 0;
}



	



