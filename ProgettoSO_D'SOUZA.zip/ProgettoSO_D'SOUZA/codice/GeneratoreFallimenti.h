#define capacity_buffer 100
/*costanti di probabilità*/
#define SIGSTOP_RANGE 99
#define SIGINT_RANGE 9999
#define SIGCONT_RANGE 9
#define SIGUSR1_RANGE 9
/*numero di processi tra quali estrarne uno*/
#define NPR 3F

int randomInteger(int min, int max);
int calculateProbability(int randomNumber); //funzione che definisce i successi dei segnali
void assignChosenPFC();
int chooseProcess();
void displaySignal(char * signal);
int pipe_desc;
int s1,s2,s3,s4; //variabili che indicano il successo delle condizioni
int process,randomNumber; //numero cardinale del processo estratto e numero randomNumber estratto
pid_t pid,pfc1,pfc2,pfc3;
FILE *fd,*fd1;
char buffer[capacity_buffer]; //buffer della lettura dei pid dei PFC

