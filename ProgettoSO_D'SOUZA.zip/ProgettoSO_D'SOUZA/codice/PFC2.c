#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
/*vengono inclusi i sorgenti con le funzioni necessarie*/
#include "updateValues.h"
#include "checkString.h"
#include "getValues.h"
#include "toRadians.h"
#include "calculateSpeed.h"
#include "sendSpeedFromPipe.h"
#include "PFC2.h"
/*gestore del segnale SIGINT*/
void gestore_SIGINT(){
	kill(getppid(),SIGUSR2);
}

/*gestore del segnale che provoca il leftshift di 2 bit*/
void gestore_SIGUSR1(){
	flag = 1;
	flag1 = 1;
}
/*gestore del segnale che uccide il Transducer e il processo stesso*/
void gestore_SIGUSR2(){
kill(tr2,SIGKILL);
kill(getpid(),SIGKILL);
}
int main(int argc, char * argv[]){
	/*assegnazione dei gestori ai segnali*/
	signal(SIGUSR1,gestore_SIGUSR1);
	signal(SIGUSR2,gestore_SIGUSR2);
	signal(SIGINT,gestore_SIGINT);
	createPipe("fifo_one");
	/*apertura file*/
    fp = fopen(argv[1],"r");
    /*creazione processo Transducer2*/
	tr2 = fork();
	if(tr2 == 0){
		execv("./Transducer2",argv);
	}		
	pipe_desc = openPipe("fifo_one");
if(fp == NULL){
    printf("PFC2: Errore apertura file di input\n");
    exit(1);
}
printf("\nFile %s aperto\n",argv[1]);
fseek(fp,0,SEEK_SET);
/*ciclo principale*/
while(1){
	/*ciclo che cerca la prima stringa valida($GPGLL)*/
	do{
		stringGPLL = fgets(buffer,capacity_buffer,fp);
		if(stringGPLL == NULL){
			stop = 1;
			break;
		}       
    }while(checkString(stringGPLL) == 0);
    /*condizione di uscita dal ciclo principale*/
    if(stop == 1){
		break;
	}
    values = getValues(stringGPLL);
    double posizione_attuale[] = {toRadians(values[0]),toRadians(values[1])};
    /*se è stata acquisita solo una posizione i valori non vengono aggiornati*/
    if(previousPosition[0] != -1 && previousPosition[1] != -1){
			speed = calculateSpeed(posizione_attuale,previousPosition);
			/*se le variabili flag e flag1 verificano la condizione la velocità subusce il left shift di 2 bit*/
			if(flag == 1 && flag1 == 2){
				int a = (int)speed;
				speed = a << 2;
				flag = 0;
				flag1 = 0;
			}
			flag1++;
		}
			updateValues(posizione_attuale,previousPosition);
    sendSpeedFromPipe(speed,pipe_desc);
    sleep(1);
}
/*terminazione del processo a file input letto completamente*/
sleep(1);
kill(tr2,SIGKILL);
close(pipe_desc);
fclose(fp);
exit(0);
}
