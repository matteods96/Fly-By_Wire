#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
/*vengono inclusi i sorgenti con le funzioni necessarie*/
#include "updateValues.h"
#include "checkString.h"
#include "getValues.h"
#include "toRadians.h"
#include "calculateSpeed.h"
#include "PFC3.h"
/*gestore del segnale SIGINT*/
void gestore_SIGINT(){
	kill(getppid(),SIGUSR2);
}

/*gestore del segnale che provoca il leftshift di 2 bit*/
void gestore_SIGUSR1(){
	flag = 1;
	flag1 = 1;
}
/*gestore del segnale che uccide il Transducer e il processo stesso*/
void gestore_SIGUSR2(){
kill(tr3,SIGKILL);
kill(getpid(),SIGKILL);
}
int main(int argc, char * argv[]){
	/*assegnazione dei gestori ai segnali*/
	signal(SIGUSR1,gestore_SIGUSR1);
	signal(SIGUSR2,gestore_SIGUSR2);
	signal(SIGINT,gestore_SIGINT);
	ind = 0;
	/*apertura file*/
	fp = fopen(argv[1],"r");
	remove("file_shared.txt");
	fp1 = fopen("file_shared.txt","w");
	/*creazione processo Transducer3*/
	tr3 = fork();
	if(tr3 == 0){
		execv("./Transducer3",argv);
	}
		if(fp == NULL){
    printf("PFC3: Errore apertura file di input\n");
    exit(1);
}
		printf("\nFile %s aperto\n",argv[1]);
		fseek(fp,0,SEEK_SET);
		/*ciclo principale*/
		while(1){
/*ciclo che cerca la prima stringa valida($GPGLL)*/			
	do{
		stringGPLL = fgets(buffer,capacity_buffer,fp);
		if(stringGPLL == NULL){
			stop = 1;
			break;
		}
    }while(checkString(stringGPLL) == 0);
    /*condizione di uscita dal ciclo principale*/
    if(stop == 1){
		break;
	}
    values = getValues(stringGPLL);
    double currentPosition[] = {toRadians(values[0]),toRadians(values[1])};
    /*se è stata acquisita solo una posizione i valori non vengono aggiornati*/
    if(previousPosition[0] != -1 && previousPosition[1] != -1){
			speed = calculateSpeed(currentPosition,previousPosition);
			/*se le variabili flag e flag1 verificano la condizione la velocità subusce il left shift di 2 bit*/
			if(flag == 1 && flag1 == 2){
				int a = (int)speed;
				speed = a << 2;
				flag = 0;
				flag1 = 0;
			}
			flag1++;
		} 
				updateValues(currentPosition,previousPosition);	
				fprintf(fp1,"%f m/s |%d\n",speed,ind++);
				fflush(fp1);
			sleep(1);
			
		}
		/*sul file file_shared.txt viene scritto '\0' per indicare che il file è finito*/
		char null[] = {'\0'};
		fwrite(null,1,sizeof(null),fp1);
		fflush(fp1);
		/*terminazione del processo a file input letto completamente*/
		sleep(1);	
		kill(tr3,SIGKILL);	
	fclose(fp);
	fclose(fp1);
	exit(0);
}
