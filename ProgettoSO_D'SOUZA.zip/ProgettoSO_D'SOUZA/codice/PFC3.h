#define capacity_buffer 100
void gestore_SIGUSR1();
void gestore_SIGUSR2();
void gestore_SIGINT();

double previousPosition[] = {-1,-1};
char buffer[capacity_buffer]; //buffer della stringa acquisita
int flag = 0; //flag che verificano la condizione per far shiftare di 2 bit la velocità
int flag1 = 0;
int stop = 0; //variabile che indica che il file G18.txt è finito
int ind;
FILE *fp,*fp1;
pid_t tr3;
double speed = 0;
char *stringGPLL; //stringa GPGLL acquisita da G18.txt
double* values; //valori acquisiti dalla stringa GPGLL

