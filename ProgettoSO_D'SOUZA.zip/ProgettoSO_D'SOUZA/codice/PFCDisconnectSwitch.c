#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <wait.h>
#include "PFCDisconnectSwitch.h"

void terminationHandler(){
	terminate();
}
/*i pid dei PFC vengono scritti su un file di testo*/
void writePidPfc(){
	fprintf(fp1,"%d\n",pfc1);
	fflush(fp1);
	fprintf(fp1,"%d\n",pfc2);
	fflush(fp1);
	fprintf(fp1,"%d\n",pfc3);
	fflush(fp1);
}
char * processName(pid_t pid){
	static char * output;
	if(pid == pfc1){
		output = PFC1;
	}
	if(pid == pfc2){
		output = PFC2;
	}
	if(pid == pfc3){
		output = PFC3;
	}
	return output;
}
void terminate(){
	/*uccisione dei figli e terminate*/
	kill(pfc1,SIGUSR2);      
	kill(pfc2,SIGUSR2);
	kill(pfc3,SIGUSR2);
	kill(genf,SIGKILL);
	kill(wes,SIGKILL);
	printf("Applicazione terminata\n");
	fflush(stdout);
	exit(0);
}

void messagesHandler(){
	fprintf(fp,"---------------------------\n");
	fflush(fp);
	char buffer[100]; //buffer contenente il messaggio d'errore inviato da Wes
	fgets(buffer,100,fpwarnings); //prima riga del messaggio contentente il messaggio da Wes
	/*controllo messaggio*/
	if(buffer[1] == 'r'){	
		fprintf(fp,"%s ",buffer);
		fflush(fp);
		pid_t pid_errore = atoi(fgets(buffer,100,fpwarnings)); //seconda riga del messaggio contenente il pid del PFC in errore
		/*stampa errore nel log*/
		fprintf(fp,"Pid: %s (%s) ",buffer,processName(pid_errore));
		fflush(fp);
		fprintf(fp,"Stato processo: %d \n",kill(pid_errore,0));
		fflush(fp);
	}
	if(buffer[1] == 'm'){
		fprintf(fp,"Emergenza\n");	
		fflush(fp);	
		
		terminate();
	}
	fprintf(fp,"---------------------------\n");
	fflush(fp);
}

int main(int argc,char * argv[]){
	/*assegnazione dei gestori ai segnali*/
	signal(SIGUSR1,messagesHandler);
	signal(SIGUSR2,terminationHandler);
	signal(SIGINT,terminationHandler);
	remove("switch.log");
	remove("pid_pfc.txt");
	/*apertura dei file*/
	fp = fopen("switch.log","w");
	if(fp == NULL){
		printf("Errore nell'apertura del file switch.log\n");
		exit(1);
	}
	fp1 = fopen("pid_pfc.txt","w");
	if(fp1 == NULL){
		printf("Errore nell'apertura del file pid_pfc.txt\n");
		exit(1);
	}
	/*creazione dei processi figli*/
	pfc1 = fork();
	if(pfc1 == 0){
		execv("./PFC1",argv);
	}else if(pfc1 > 0){
		pfc2 = fork();
		if(pfc2 == 0){
			execv("./PFC2",argv);
		}else if(pfc2 > 0){
			pfc3 = fork();
			if(pfc3 == 0){
				execv("./PFC3",argv);
			}else if(pfc3 > 0){
				wes = fork();
				if(wes == 0){
					execv("./Wes",argv);
				}else if(wes > 0){
					genf = fork();
					if(genf == 0){
						execv("./GeneratoreFallimenti",argv);
					}else{
						sleep(1);
						fpwarnings = fopen("warnings.txt","r");
						if(fpwarnings == NULL){
							printf("Errore apertura del file warnings.txt\n");
							exit(1);
						}
						/*attesa che uno tra i tre PFC termini(gli altri figli non terminano autonomamente) */
						writePidPfc();
						wait(NULL);
						terminate();
					}
				}
			}
		}
	}
}
	
	

