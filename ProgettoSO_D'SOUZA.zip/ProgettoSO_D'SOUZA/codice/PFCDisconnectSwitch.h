#define PFC1 "PFC1"
#define PFC2 "PFC2"
#define PFC3 "PFC3"
char * processName(pid_t pid);
void gestore_SIGUSR2();
void messagesHandler();
void writePidPfc();
void terminate();

int pipe_desc; //descrittore pipe
FILE *fp,*fp1,*fpwarnings;  
pid_t genf,wes; //pid dei processi figli
pid_t pfc1,pfc2,pfc3;
