#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include "receiveSpeedFromSocket.h"

FILE *fp;
double speed = 0;
int ind;

int main(){
	speed = 0;
	createSocketClient();
	/*apertura file*/
	remove("speedPFC1.log");
	fp = freopen("speedPFC1.log", "w", stdout); 
	if(fp == NULL){
		printf("Errore in apertura del file speedPFC1.log\n");
	}
	sleep(1);
	/*ciclo di lettura della velocità dalla socket*/
	while(1){		 
		speed = receiveSpeedFromSocket();
		if(speed != -1){
		printf("%f m/s |%d\n",speed,ind++);
		fflush(stdout);
	}
		speed = -1;
		sleep(1);	
	}
	fclose(fp);
	exit(0);
}







