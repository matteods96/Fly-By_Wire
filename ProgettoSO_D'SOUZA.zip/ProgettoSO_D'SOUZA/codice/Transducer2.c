#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "receiveSpeedFromPipe.h"
FILE *fp;
int ind,pipe_desc;
double speed = 0;

int main(){
	/*apertura file*/
	remove("speedPFC2.log");
	fp = fopen("speedPFC2.log","w");
	ind = 0;
	
	if(fp == NULL){
		printf("Transducer2: Errore apertura file log\n");
	}
	
	pipe_desc = openPipe("fifo_one");
	
	sleep(1);
	/*ciclo di lettura della velocità dalla pipe*/
	while(1){
		speed = receiveSpeedFromPipe(speed,pipe_desc);
		if(speed != -1){
		fprintf(fp,"%f m/s |%d\n",speed,ind++);
	}
		
		fflush(fp);
		speed = -1;
		sleep(1);
	}
	fclose(fp);
	exit(0);
}
