#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
FILE *fp1;
FILE *fp2;

int main(){
	/*apertura file*/
	remove("speedPFC3.log");
    fp1= fopen("speedPFC3.log","w");
	fp2 = fopen("file_shared.txt","r");
	if(fp1 == NULL){
		printf("Transducer3: Errore apertura file log\n");
	}
	if(fp2 == NULL){
		printf("Transducer3: Errore apertura file condiviso\n");
		exit(1);
	}
	sleep(1);
	/*ciclo di lettura della velocità dal file condiviso*/
	while(1){
		char buffer[100];
		fgets(buffer,100,fp2);
		if(buffer != '\0'){
			fprintf(fp1,"%s",buffer);
			fflush(fp1);
		}
		fflush(fp1);
		buffer[0] = '\0';
		sleep(1);
	}
	fclose(fp1);
	fclose(fp2);
	exit(0);
}
