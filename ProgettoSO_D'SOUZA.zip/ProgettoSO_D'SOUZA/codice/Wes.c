#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include "sendSpeedFromPipe.h"
#include "Wes.h"
/*funzione che scrive "Errore" sul file di log e indica il processo in errore nel file condiviso con PFCDisconnectSwitch*/
void writeError(pid_t pid){
	printf("Errore\n");
	fflush(stdout);
	fprintf(fplog,"Errore |%d\n",ind++);
	fflush(fplog);
	fprintf(fpwarnings,"Errore\n%d\n",pid);	
	fflush(fpwarnings);
}

int main() {
	errorDone = 0;
	ind = 0;
	differencesCounter=0;
/*apertura file*/	
	remove("warnings.txt");
	fpwarnings = fopen("warnings.txt","w");
	
	sleep(1);
	
    fppid = fopen("pid_pfc.txt","r");
 /*acquisizione dei pid dei PFC dal file pid_pfc.txt*/   
	pfc1 = atoi(fgets(buffer,capacity_buffer,fppid));
	pfc2 = atoi(fgets(buffer,capacity_buffer,fppid));
	pfc3 = atoi(fgets(buffer,capacity_buffer,fppid));
	
	fp1 = fopen("speedPFC1.log", "r");
	fp2 = fopen("speedPFC2.log", "r");
	fp3 = fopen("speedPFC3.log", "r");
	remove("status.log");
	fplog = fopen("status.log","w");   
	    
	while (1){
		
		sleep(1);
	/*acquisizione valori di velocità dai file di log speedPFC*/		 
		str1=fgets(buf1, capacity_buffer, fp1);
		str2=fgets(buf2, capacity_buffer, fp2);
		str3=fgets(buf3, capacity_buffer, fp3);
	/*confronto valori*/	
		if(strcmp(buf1,buf2)!=0 ){
			differencesCounter++;
		}
		if(strcmp(buf1,buf3)!=0){
			differencesCounter++;
		}
		if(strcmp(buf3,buf2)!=0){
			differencesCounter++;
		}
	/*controllo se tutti i file di log speedPFC sono terminati*/	
		if(str1==NULL && str2==NULL && str3==NULL){
			printf("Fine\n");
			break;
		}
	/*determinazione errore in base al numero di discrepanze*/	
		if(differencesCounter==3){
			printf("Emergenza\n");
			fprintf(fplog,"Emergenza |%d\n",ind++);
			fflush(fplog);
			fprintf(fpwarnings,"Emergenza\n");
			fflush(fpwarnings);
			kill(getppid(),SIGUSR1);
			errorDone = 1;	
		}
		if(differencesCounter==2){
			if((strcmp(buf1,buf2)!=0) &&(strcmp(buf1,buf3)!=0)){
				
				fprintf(fplog,"PFC1 ");
				fflush(fplog);
				writeError(pfc1);
				kill(getppid(),SIGUSR1);
				errorDone = 1;
			}
			if((strcmp(buf1,buf3)!=0) && (strcmp(buf3,buf2)!=0)){
				
				fprintf(fplog,"PFC3 ");
				writeError(pfc3);
				kill(getppid(),SIGUSR1);
				errorDone = 1;
			}
			if((strcmp(buf3,buf2)!=0) &&(strcmp(buf1,buf2)!=0)){
				
				fprintf(fplog,"PFC2 ");
				writeError(pfc2);
				kill(getppid(),SIGUSR1);
				errorDone = 1;
			}	
		}
		if(errorDone == 0){
			printf("Ok\n");
			fprintf(fplog,"Ok |%d\n",ind++);
			fflush(fplog);
		}
	/*dopo ogni errore scritto le variabili vengono azzerate*/	
		differencesCounter = 0;
		errorDone = 0;
	
	}	
	fclose(fp1);
	return 0;
}

