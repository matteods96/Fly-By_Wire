#define capacity_buffer 100

void writeError(pid_t pid);

int errorDone; // flag che indica se è stato trovato un errore
int ind;
int differencesCounter; //indica il numero di discrepanze trovate
pid_t pfc1,pfc2,pfc3;
FILE *fp1,*fp2,*fp3,*fplog,*fppid,*fpwarnings;
char *str1,*str2,*str3; //puntatori alle stringhe dei valori di velocità degli speedPFC
char buffer[capacity_buffer]; // contiene il contenuto del file pid_pfc.txt
char buf1[capacity_buffer]; //contengono i valori di velocità
char buf2[capacity_buffer];
char buf3[capacity_buffer];

