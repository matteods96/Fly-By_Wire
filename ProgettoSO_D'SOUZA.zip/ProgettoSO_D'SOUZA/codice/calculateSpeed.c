#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "calculateSpeed.h"

double calculateSpeed(double * position1,double * position2){
	
	double a = pow(sin((position1[0]-position2[0])/2),2) + (cos(position1[0])*cos(position2[0])*pow(sin((position1[1]-position2[1])/2),2));
	double c = 2 * atan2(sqrt(a),sqrt(1-a));
	double d = RADIUS * c; //distanza in metri
	//int delta_t = ((ora1[0]-ora2[0])*3600)+((ora1[1]-ora2[1])*60)+((ora1[2]-ora2[2]));
	int delta_t = 1;
	if(delta_t != 0){
		return d / delta_t;
	}
	return -1;
}


