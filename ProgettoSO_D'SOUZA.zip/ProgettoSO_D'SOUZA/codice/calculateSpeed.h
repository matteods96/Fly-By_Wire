#define RADIUS 6377726 //RADIUS della terra su Genova
double calculateSpeed(double * position1,double * position2);

