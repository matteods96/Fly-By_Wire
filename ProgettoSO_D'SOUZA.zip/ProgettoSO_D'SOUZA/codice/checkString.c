#include <stdio.h>
#include <stdlib.h>
#include "checkString.h"

int checkString(char * str){
    return str[4] == 'L';
}

