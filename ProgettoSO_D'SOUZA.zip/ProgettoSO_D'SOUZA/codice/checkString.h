int checkString(char * str);

