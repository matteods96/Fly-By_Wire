#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "getValues.h"

int longitudine_negativa = 0;
int latitudine_negativa = 0;

/*in queste funzioni va in ingresso un array di interi contenente i valori di latitudine e longitudine attaccati senza virgola*/
double calculateLatitude(int*a){
 double x=0;
 for(int i=INDEX_START_LATITUDE;i<INDEX_END_LATITUDE;i++)
 {
   x=10*x+a[i];
 }
 if(latitudine_negativa == 1){
	x = -x;
 }
 latitudine_negativa = 0;
 return x/1000000; //per avere l'output nel formato giusto si sposta la virgola come indicato dalle specifiche
}
double calculateLongitude(int*a){
 double x=0;
for(int i=INDEX_START_LONGITUDE;i<INDEX_END_LONGITUDE;i++)
{
  x=10*x+a[i];
}
if(longitudine_negativa == 1){
	x = -x;
 }
 longitudine_negativa = 0;
return x/1000000;
 
} 
double * getValues(char * res) {
	static double output[2];
 int array[LENGHT_FIELD_LAT_LONG];
		int j = 0; //indice dell'array che va in ingresso alle funzioni di calcolo
		/*inserimento dei valori nell'array da passare alle funzioni di calcolo*/
        for (int i=INDEX_START_FIELD_LAT_LONG;i<INDEX_END_STRING;i++){
	if((res[i]!='.') &(res[i]!=',')){
		if(res[i]=='S'){
			longitudine_negativa = 1;
		}else if(res[i]=='W'){
			latitudine_negativa = 1;
		}else if((res[i]!='N')&(res[i]!='E')){
			array[j]=res[i]-'0';
			j++;
		}
	}
 
   }      
   output[0] = calculateLatitude(array);
   output[1] = calculateLongitude(array);
 return output;
}

