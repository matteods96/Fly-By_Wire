double calculateLatitude(int*a);
double calculateLongitude(int*a);
double * getValues(char * res);
/*indici di lettura dei valori latitudine e longitudine nelle stringhe GPGLL*/
#define INDEX_END_STRING 31
#define INDEX_START_FIELD_LAT_LONG 7
#define INDEX_START_LATITUDE 0
#define INDEX_END_LATITUDE 8
#define INDEX_START_LONGITUDE 8
#define INDEX_END_LONGITUDE 17
#define LENGHT_FIELD_LAT_LONG 22

