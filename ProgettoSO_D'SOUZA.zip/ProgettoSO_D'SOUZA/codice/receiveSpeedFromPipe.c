#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include "receiveSpeedFromPipe.h"

int openPipe(char * name){
	//printf("Apertura pipe\n");
	int pipe_desc = open(name, O_RDONLY);
	//printf("Pipe aperto\n");
	
	if(pipe_desc == -1){
		printf("Errore nella scrittura del valore\n");
		exit(1);
	}
	return pipe_desc;
}

double receiveSpeedFromPipe(double speed,int pipe_desc){
	read(pipe_desc, &speed, sizeof(double));
	return speed;
}
