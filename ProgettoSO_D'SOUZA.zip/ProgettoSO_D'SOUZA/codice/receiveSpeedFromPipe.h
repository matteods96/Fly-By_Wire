int openPipe(char * name);
double receiveSpeedFromPipe(double speed,int pipe_desc);

