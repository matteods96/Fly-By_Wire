#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <unistd.h>
#include "receiveSpeedFromSocket.h"

int sockfd= 0;
    int len= 0;
    struct sockaddr_un address = { .sun_family = AF_UNIX };
    int result;

int createSocketClient(){
	int result;
	sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
	address.sun_family = AF_UNIX;
    strcpy(address.sun_path, "server_socket");
    len = sizeof(address);
    result = connect(sockfd, (struct sockaddr *)&address, len);
	printf("Connesso al server\n");
	return result;
}
double receiveSpeedFromSocket(){
	static double output;
	read(sockfd, &output, 100);
	return output;
}



	
