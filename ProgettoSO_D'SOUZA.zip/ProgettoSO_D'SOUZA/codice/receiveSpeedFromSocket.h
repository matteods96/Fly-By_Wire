#include <sys/un.h>
int createSocketClient();
double receiveSpeedFromSocket();

extern int sockfd;
    extern int len;
    extern struct sockaddr_un address;
    extern int result;


