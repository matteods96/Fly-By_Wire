#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include "sendSpeedFromPipe.h"


void createPipe(char * name){
	remove(name);//se esiste già la pipe vviene eliminata
	if(mkfifo(name, 0777) == -1){
		/*se non è stato possibile crearla e non esiste di già la pipe, allora c'è un errore*/
		if(errno != EEXIST){
			printf("Errore nella creazione del file fifo\n");
			exit(1);
		}
		
	}
}
int openPipe(char * name){
	int pipe_desc = open(name, O_WRONLY);
	printf("Pipe %s aperto\n",name);
	
	if(pipe_desc == -1){
		printf("Errore nella scrittura del valore\n");
		exit(1);
	}
	return pipe_desc;
}
void sendSpeedFromPipe(double speed, int pipe_desc){
	write(pipe_desc, &speed, sizeof(double));
}


