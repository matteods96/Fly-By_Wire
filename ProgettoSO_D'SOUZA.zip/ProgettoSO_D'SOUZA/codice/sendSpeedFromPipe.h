void createPipe(char * name);
int openPipe(char * name);
void sendSpeedFromPipe(double speed,int pipe_desc);

