#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <sys/un.h>//struttura degli indirizzi
#include <unistd.h>
#include "sendSpeedFromSocket.h"

int server_sockfd, client_sockfd =0; //desccrittori del server e del client
    int server_len, client_len= 0; //lunghezza indirizzi
    struct sockaddr_un server_address= { .sun_family = AF_UNIX }; //indirizzi server e client
    struct sockaddr_un client_address= { .sun_family = AF_UNIX };
int createSocketServer(){
	unlink("server_socket"); // se la socket esiste già viene eliminata
    server_sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
	/*assegnazione parametri*/
	server_address.sun_family = AF_UNIX;
    strcpy(server_address.sun_path, "server_socket");
    server_len = sizeof(server_address);
    bind(server_sockfd, (struct sockaddr *)&server_address, server_len);
	                                                                   
	listen(server_sockfd, 2000); //le richieste massime sono impostate a un valore leggermente più alto del numero di stringhe di G18.txt                 
	return server_sockfd;
}
void waitClient(){
	printf("Server in attesa\n");
	
	while(client_sockfd == 0){
		client_len = sizeof(client_address);
        client_sockfd = accept(server_sockfd,(struct sockaddr *)&client_address, &client_len);
	}
	printf("Connesso al client\n"); 
}
void sendSpeedFromSocket(double speed){
		write(client_sockfd, &speed, 100);
}


	
