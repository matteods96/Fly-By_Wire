#include <sys/un.h> //contiene la struttura sockaddr_un
#include <sys/socket.h>
	int createSocketServer();
    void sendSpeedFromSocket(double speed);
    void waitClient();
    
    extern int server_sockfd, client_sockfd; //desccrittori del server e del client
    extern int server_len, client_len; //lunghezza indirizzi
    extern struct sockaddr_un server_address; //indirizzi server e client
    extern struct sockaddr_un client_address;

