#include <stdio.h>
#include <math.h>
#include "toRadians.h"
double toRadians(double val){
return (val * M_PI)/180;
}

