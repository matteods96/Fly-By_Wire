#include "updateValues.h"
void updateValues(double * currentPosition, double * previousPosition){
	previousPosition[0] = currentPosition[0];
    previousPosition[1] = currentPosition[1];
}
