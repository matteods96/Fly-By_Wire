void updateValues(double * currentPosition, double * previousPosition);
